#!/usr/bin/env bash
set -e
FINELY_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$FINELY_DIR"

# Start Ollama in background if not already responding
if ! curl -s -o /dev/null -w "%{http_code}" http://localhost:11434/api/tags 2>/dev/null | grep -q 200; then
  echo "Starting Ollama..."
  ollama serve &
  sleep 2
fi

# Prefer .venv, fallback to .venv-mlx
if [ -d ".venv" ]; then
  source .venv/bin/activate
elif [ -d ".venv-mlx" ]; then
  source .venv-mlx/bin/activate
else
  echo "No .venv or .venv-mlx found. Create one and install deps first."
  exit 1
fi

echo "Starting Finelly at http://localhost:8000"
exec uvicorn app.main:app --reload
