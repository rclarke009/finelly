@echo off
cd /d "%~dp0"

echo Starting Finelly (Ollama + app)...
docker compose up -d

echo Waiting for Ollama to be ready...
:wait
docker compose exec ollama ollama list >nul 2>&1
if errorlevel 1 (
  timeout /t 3 /nobreak >nul
  goto wait
)

echo Checking models (skip if already installed)...
docker compose exec ollama ollama list 2>nul | findstr /C:"llama3.1:8b" >nul 2>&1
if errorlevel 1 (
  echo Pulling llama3.1:8b...
  docker compose exec ollama ollama pull llama3.1:8b
) else echo llama3.1:8b already present.
docker compose exec ollama ollama list 2>nul | findstr /C:"nomic-embed-text" >nul 2>&1
if errorlevel 1 (
  echo Pulling nomic-embed-text...
  docker compose exec ollama ollama pull nomic-embed-text
) else echo nomic-embed-text already present.
docker compose exec ollama ollama list 2>nul | findstr /C:"llava" >nul 2>&1
if errorlevel 1 (
  echo Pulling llava...
  docker compose exec ollama ollama pull llava
) else echo llava already present.

echo.
echo Ready. Opening browser...
start http://localhost:8000/
echo To stop later: docker compose down
pause
